 | Heading1 | Heading2 |
 | -------- | -------- |
 | Content1 | Content2 |
 |          |          |