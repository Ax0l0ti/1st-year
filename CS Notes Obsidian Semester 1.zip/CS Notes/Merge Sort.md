### Merge Sort

1. Split it in two halves
2. Recursively sort each half
3. Merge the sorted lists