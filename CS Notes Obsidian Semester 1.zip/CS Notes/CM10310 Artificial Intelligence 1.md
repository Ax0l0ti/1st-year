# Artificial Intelligence
---
*Date :*  03-10-2022 
*Module :* #CM10310
*Teacher*: [Ben Ralph](https://moodle.bath.ac.uk/user/profile.php?id=71461), #OlgaIsupova, #EmelieBarman
*Resources :*

---
##### Contents: 
> [[What is AI ]]
> [[The Turing Test ]]
> [[AI Ethics ]]
> [[Uniformed Search]]
> [[Informed Search]]
> [[Adversarial Search]]
> [[Introduction to Probability]]
> [[Marko Decission Procedures]]
> [[Bayesian Networks]]
> 
--- 

###### Coursework 1 (30%)
Python Based
Deadline in week 12 (January)

###### Coursework 2 (20%)
Python Based
Deadline in Week 6

###### Coursework 3 (20%)
Python Based

###### Exam (30%)
End of semester 2 (June)
Multiple choice questions
Closed Book 


Standard book for reading in the field of AI is Artificial Intelligence by Russell and Norvig. 3rd Edition is the main reference. 