# The Turing Test
---
*Date :*  17-10-2022 
*Module :* #CM10310 
*Teacher*: 
*Resources :*

---
##### Contents: 
> [[# ]]
> [[# ]]
> [[# ]]
> 
--- 

Turing test is used to test whether a system is acting/thinking like humans or rationally. 
![[Pasted image 20221017163501.png | 300]]

###### Visual Turing test
- Questions with binary answers 
- The answer to the next question is not predictable given previous answers

One experiment conducted to test if the turing test can actually be used to distinguish human from AI is the chinese room experiment. 

