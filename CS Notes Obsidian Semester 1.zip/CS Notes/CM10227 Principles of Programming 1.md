# Principles of Programming 1
---
*Date :*  04-10-2022 
*Module :* #CM10227
*Teacher*: #DrWillemHeijltjes , [Zack Lyons](https://moodle.bath.ac.uk/user/profile.php?id=25337)
*Resources :*

---
##### Contents: 
> [[Programming]]
> [[The C programming language]]
> [[# ]]
> 
--- 

The module is 100% coursework based. 
	- Python 50%
	- Java 50% 

Coursework 1 Set: 18th October Deadline: 4th November
Cooursework 2 set: 29th November Deadline: 16th December 