# What is AI
---
*Date :*  10-10-2022 
*Module :* #CM10310 
*Teacher*: #EmelieBarman
*Resources :*

---
##### Contents: 
> [[# ]]
> [[# ]]
> [[# ]]
> 
--- 

AI is about constrained knowledge representations that support the making of models to facilitate an understanding of thinking, perception, and action.

Characteristics that define an AI can be categorised into: 
	- Thinking Humanly (HT)
	- Behaving humanly (HB)
	- Thinking rationally / ideally (IT)
	- Behaving rationally / ideally (IB)