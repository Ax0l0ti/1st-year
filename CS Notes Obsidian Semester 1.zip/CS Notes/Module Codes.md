# Module Codes

###### [[CM10194 Computer System Architecture 1]]
###### [[CM10195 Computer System Architecture 2]]
###### [[CM10227 Principles of Programming 1]]
###### [[CM10228 Principles of Programming 2]]
###### [[CM10310 Artificial Intelligence 1]]
###### [[CM10311 Discrete Mathematics and Databases]]
###### [[CM10312 Mathematics of Computation]] 
###### [[CM10313 Software processes and Modelling]]
