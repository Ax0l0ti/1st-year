# Computer System Architecture 1
---
*Date :*  03-10-2022 
*Module :* #CM10194
*Teacher*: [Fabio Nemetz](https://moodle.bath.ac.uk/user/profile.php?id=490)
*Resources :* [[CM10194 - SA1 LN.pdf | Lecture Notes 01 ]] , [[arduino_projects_book.pdf |Arduino Booklet]]
*Past Papers :* [Past Papers - OneDrive](https://computingservices-my.sharepoint.com/personal/sb3250_bath_ac_uk/_layouts/15/onedrive.aspx?login_hint=sb3250%40bath%2Eac%2Euk&id=%2Fpersonal%2Fsb3250%5Fbath%5Fac%5Fuk%2FDocuments%2FResources%2FSystem%20Architecture%2FPast%20Papers)

---
##### Contents: 
> [[Brief history of Computer]] 
> [[Architecture ]]  
> [[Data Representation]]
> [[Data Storage]]
> [[Instructions]]
  
--- 

![[Assessment and coursework details.png | 500]]

![[Pasted image 20221003114337.png | 400]]

