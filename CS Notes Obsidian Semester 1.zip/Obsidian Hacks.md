# Obsidian Hacks

You can use # to define **headings**. A single # is heading 1 and the more you add the smaller the text gets. Can use up to 6 headings. 

**Bullet lists** can be made just by typing - or numbers. 

To create **checkboxes** use -[  ] at the start of a line.   

**Web embeds** can be created using this format. ![ ](link)
You can start a **blockquote** using > at the start of a line. 

Backticks used for single line **code**. Three backticks for multiline code. 

Use two equal signs to ==highlight text== . 

Three hyphens to create a **horizontal line**. --- 

ctrl + T for **templates**
